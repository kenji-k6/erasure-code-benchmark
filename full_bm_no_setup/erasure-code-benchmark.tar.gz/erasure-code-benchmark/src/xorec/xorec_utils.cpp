#include "xorec_utils.hpp"

std::array<uint8_t, XOREC_MAX_DATA_BLOCKS> COMPLETE_DATA_BITMAP = {0};