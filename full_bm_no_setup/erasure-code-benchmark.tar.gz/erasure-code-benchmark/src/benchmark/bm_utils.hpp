#ifndef BM_UTILS_HPP
#define BM_UTILS_HPP
#include <string>
#include <vector>

void print_usage();
void parse_args(int argc, char** argv);
void run_benchmarks();

#endif // BM_UTILS_HPP