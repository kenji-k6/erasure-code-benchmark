#include "bm_config.hpp"

const std::vector<size_t> VAR_BLOCK_SIZES = { 4096, 8192, 16384, 32768, 65536, 131072, 262144 };
const std::vector<FECTuple> VAR_FEC_PARAMS = { {2,1}, {4,2}, {8,4}, {16,4}, {16,8}, {32,4}, {32, 8} };
const std::vector<size_t> VAR_NUM_CPU_THREADS = { 1, 2 };